(()=>{
const pg=document.body.dataset.page,order=['index','birthday','strong','healer','distance','letter','surprise','forever'];
const names=['Welcome','Birthday','Strong','Healer','Distance','Letter','Surprise','Forever'];
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;
/* ---------- particles + confetti ---------- */
const cv=$('#fx'),cx=cv.getContext('2d');let W,H,P=[],C=[];
function size(){const d=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;cv.width=W*d;cv.height=H*d;cx.setTransform(d,0,0,d,0,0);
 P=Array.from({length:W<600?32:64},()=>({x:Math.random()*W,y:Math.random()*H,r:Math.random()*2+.6,s:Math.random()*.5+.15,p:Math.random()*6.28}))}
addEventListener('resize',size);size();
const cols=['#f6e27a','#d4af37','#fff3b0','#b8962e','#ffffff'];
window.confetti=(n=120,x=W/2,y=H/3)=>{for(let i=0;i<n;i++)C.push({x,y,vx:(Math.random()-.5)*11,vy:Math.random()*-10-2,w:Math.random()*8+4,h:Math.random()*5+3,a:Math.random()*6,va:(Math.random()-.5)*.4,c:cols[i%5],l:0})};
(function loop(){cx.clearRect(0,0,W,H);
 if(!reduce)P.forEach(o=>{o.y-=o.s;o.p+=.03;if(o.y<-8){o.y=H+8;o.x=Math.random()*W}const a=.35+.35*Math.sin(o.p);
  cx.fillStyle='rgba(246,226,122,'+a*.18+')';cx.beginPath();cx.arc(o.x,o.y,o.r*4,0,6.28);cx.fill();
  cx.fillStyle='rgba(255,236,150,'+a+')';cx.beginPath();cx.arc(o.x,o.y,o.r,0,6.28);cx.fill()});
 C=C.filter(p=>p.y<H+30&&p.l<400);C.forEach(p=>{p.l++;p.vy+=.22;p.vx*=.99;p.x+=p.vx;p.y+=p.vy;p.a+=p.va;cx.save();cx.translate(p.x,p.y);cx.rotate(p.a);cx.fillStyle=p.c;cx.fillRect(-p.w/2,-p.h/2,p.w,p.h);cx.restore()});
 requestAnimationFrame(loop)})();
/* ---------- original melody (Web Audio) ---------- */
const F={C3:130.81,C4:261.63,D4:293.66,E4:329.63,G4:392,A4:440,C5:523.25,D5:587.33,E5:659.25};
const seq=[['E4',1],['G4',1],['A4',1],['G4',1],['E4',1],['D4',1],['C4',2],['D4',1],['E4',1],['G4',1],['A4',1],['C5',1.5],['A4',.5],['G4',2],['E5',1],['D5',1],['C5',1],['A4',1],['G4',1],['A4',1],['E4',2],['D4',1],['E4',1],['G4',1],['E4',1],['C4',4]];
let ac,master,timer,playing=false;const beat=.85;
function tone(f,t,d,v,type){const o=ac.createOscillator(),g=ac.createGain();o.type=type;o.frequency.value=f;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+.04);g.gain.exponentialRampToValueAtTime(.0008,t+d);o.connect(g);g.connect(master);o.start(t);o.stop(t+d+.05)}
function bar(){let t=ac.currentTime+.1;const total=seq.reduce((a,n)=>a+n[1],0)*beat;
 seq.forEach(([n,b])=>{tone(F[n],t,b*beat*1.5,.16,'triangle');t+=b*beat});
 for(let k=0;k<total;k+=beat*4)tone(F.C3,ac.currentTime+.1+k,beat*4,.12,'sine');
 timer=setTimeout(bar,(total-.3)*1000)}
const btn=document.createElement('button');btn.id='mus';btn.setAttribute('aria-label','Play or pause music');btn.textContent='♪';document.body.appendChild(btn);
function start(){if(playing)return;if(!ac){ac=new(window.AudioContext||window.webkitAudioContext)();master=ac.createGain();const dl=ac.createDelay();dl.delayTime.value=.32;const fb=ac.createGain();fb.gain.value=.3;dl.connect(fb);fb.connect(dl);master.connect(ac.destination);master.connect(dl);dl.connect(ac.destination)}
 ac.resume();master.gain.setTargetAtTime(.9,ac.currentTime,.3);bar();playing=true;btn.classList.add('on');btn.textContent='❚❚';sessionStorage.mus='1'}
function stop(){clearTimeout(timer);if(master)master.gain.setTargetAtTime(0,ac.currentTime,.1);playing=false;btn.classList.remove('on');btn.textContent='♪';sessionStorage.mus='0'}
btn.onclick=e=>{e.stopPropagation();playing?stop():start()};
if(sessionStorage.mus==='1'){const arm=()=>{start();removeEventListener('pointerdown',arm)};addEventListener('pointerdown',arm)}
/* ---------- nav + transitions ---------- */
const i=order.indexOf(pg);
if(i>0){const n=document.createElement('div');n.className='nav';
 n.innerHTML='<a href="'+order[i-1]+'.html">‹ '+names[i-1]+'</a><div class="dots">'+order.map((o,k)=>'<i class="'+(k==i?'on':'')+'"></i>').join('')+'</div>'+(i<7?'<a href="'+order[i+1]+'.html">'+names[i+1]+' ›</a>':'<a href="index.html">Replay ↻</a>');
 document.body.appendChild(n)}
document.addEventListener('click',e=>{const a=e.target.closest('a[href$=".html"]');if(!a||a.target||e.metaKey||e.ctrlKey)return;e.preventDefault();document.body.classList.add('leave');setTimeout(()=>location.href=a.getAttribute('href'),380)});
addEventListener('pageshow',()=>document.body.classList.remove('leave'));
const io=new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&e.target.classList.add('show')),{threshold:.15});$$('.reveal').forEach(el=>io.observe(el));
/* ---------- index: cinematic intro ---------- */
if(pg==='index'){const ov=$('.intro'),p=$('p',ov);let skip=false;
 $('button',ov).onclick=()=>{skip=true;start()};
 (async()=>{const L=['Some people walk into your life…','and quietly become your whole safe place.','2.5 years. One bestest friend.','Today is all about you, Vro.'];
  for(const l of L){if(skip)break;p.textContent=l;p.style.opacity=1;await sleep(2300);p.style.opacity=0;await sleep(1000)}
  ov.style.opacity=0;await sleep(1200);ov.remove()})();
 $('button',ov).addEventListener('click',()=>{ov.style.opacity=0;setTimeout(()=>ov.remove(),1200)})}
/* ---------- birthday: cake ---------- */
if(pg==='birthday'){const cs=$$('.candle'),m=$('#cakeMsg');let out=0;
 setTimeout(()=>confetti(90,innerWidth/2,innerHeight/3),700);
 cs.forEach(c=>c.onclick=()=>{if(c.classList.contains('out'))return;c.classList.add('out');out++;const r=c.getBoundingClientRect();confetti(40,r.left,r.top);
  m.textContent=out<cs.length?'Make a wish, Thangooo… '+(cs.length-out)+' to go ✨':'Wish made! Indha year unakku romba romba special-a irukkum, Vro. 🤍';
  if(out==cs.length){confetti(260,innerWidth/2,innerHeight/2);setTimeout(()=>confetti(160,innerWidth/4,innerHeight/3),400);setTimeout(()=>confetti(160,innerWidth*.75,innerHeight/3),700)}});
 $('#again').onclick=()=>{cs.forEach(c=>c.classList.remove('out'));out=0;m.textContent='Light up again — tap a candle to blow it out ✨'};
 $('#party').onclick=()=>{confetti(220,innerWidth/2,innerHeight/2.5);start()}}
/* ---------- healer ---------- */
if(pg==='healer'){const M=['Vro, you listened when I could not even explain what was wrong.','Un kitta pesina piragu, en bharam half-a kuranjidum. Always.','You never judged me. You just stayed.','Healers need healing too — so today, let me be there for you.','Thank you for every "Nee onnum feel pannaadha, naan irukken".'];let k=0;
 $('#heal').onclick=()=>{const e=$('#healMsg');e.style.opacity=0;setTimeout(()=>{e.textContent=M[k++%M.length];e.style.opacity=1},250);confetti(20,innerWidth/2,innerHeight*.6)}}
/* ---------- distance slider ---------- */
if(pg==='distance'){const s=$('#gap'),a=$('#oa'),b=$('#ob'),t=$('#gapMsg');
 const u=()=>{const v=+s.value,d=Math.min(innerWidth/2-50,280)*v/100;a.style.transform='translateX('+-d+'px)';b.style.transform='translateX('+d+'px)';
  t.textContent=v<8?'Side by side again — the old bench, the old laughs. That is the dream, Vro. 🤍':v<50?'Almost there… I can already hear your laugh.':'Different places, same bond. Drag the slider to bring us closer.';if(v==0)confetti(60)};
 s.oninput=u;u()}
/* ---------- surprise: tiles + quiz ---------- */
if(pg==='surprise'){$$('.tile').forEach(t=>t.onclick=()=>{if(!t.classList.contains('open')){t.classList.add('open');const r=t.getBoundingClientRect();confetti(25,r.left+r.width/2,r.top)}});
 const Q=[['Which one is NOT one of her nicknames?',['Vro','Thangooo','HEALER','Captain'],3],['How long has this friendship been going strong?',['6 months','1 year','2.5 years','10 years'],2],['What is her biggest superpower in my life?',['Fixing my bad days with one talk','Cooking','Maths','Running'],0],['What do I miss the most?',['Exam days','Sitting beside her in class','Early mornings','Homework'],1],['Which date is the best day of the year?',['November 12','December 12','November 21','October 12'],0]];
 let qi=0,sc=0;const box=$('#quiz');
 function show(){if(qi>=Q.length){box.innerHTML='<h3>Score: '+sc+' / '+Q.length+'</h3><p>Score enna irundhaalum — you are the answer to every right question, Vro. 🤍</p><button class="btn" id="rq">Play again</button>';if(sc==Q.length)confetti(200);$('#rq').onclick=()=>{qi=0;sc=0;show()};return}
  const q=Q[qi];box.innerHTML='<p class="eyebrow">Question '+(qi+1)+' of '+Q.length+'</p><h3>'+q[0]+'</h3>';
  q[1].forEach((o,k)=>{const b=document.createElement('button');b.className='btn opt';b.textContent=o;b.onclick=()=>{$$('.opt',box).forEach(x=>x.disabled=true);if(k==q[2]){b.classList.add('ok');sc++}else{b.classList.add('no');$$('.opt',box)[q[2]].classList.add('ok')}setTimeout(()=>{qi++;show()},1100)};box.appendChild(b)})}
 show()}
/* ---------- forever: final surprise ---------- */
if(pg==='forever'){$('#last').onclick=async function(){this.classList.add('hide');start();for(let k=0;k<7;k++){confetti(120,Math.random()*innerWidth,innerHeight*.25);await sleep(450)}$('#final').classList.remove('hide');$('#final').classList.add('show');$('#final').scrollIntoView({behavior:'smooth',block:'center'})}}
})();
